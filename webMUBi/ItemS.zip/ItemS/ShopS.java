package com.girlkun.ItemS;

import com.girlkun.services.ItemService;
import com.girlkun.services.*;
import com.girlkun.models.item.Item;
import com.girlkun.result.GirlkunResultSet;
import com.girlkun.server.ServerManager;
import com.girlkun.models.player.Player;
import com.girlkun.database.GirlkunDB;
import org.json.simple.JSONValue;
import org.json.simple.JSONArray;
import com.girlkun.server.Client;
import java.util.ArrayList;
import java.util.List;

public class ShopS implements Runnable {
     public static ShopS i;
     
     public long lastTimeShop;
     
    // public int timeSet = 300;
    public int timeSet = 5;
     
     public static ShopS gI(){
         if (i == null){
             i = new ShopS();
         }
           return i;
     }
     
   @Override
    public void run() {
      while (ServerManager.isRunning) {
          if (lastTimeShop < (System.currentTimeMillis() - (timeSet * 1000))){
              lastTimeShop = System.currentTimeMillis();
               try {
            GirlkunResultSet rs = GirlkunDB.executeQuery("SELECT * FROM shops_web");
                 while (rs.next()) {
                    int uid = rs.getInt("uid");
                    int id = rs.getInt("id");
                    boolean status = (rs.getInt("status") == 0);
                    if (status){
                         Player pl = Client.gI().getPlayer((long) uid);
                         if (pl != null){
                            if (InventoryServiceNew.gI().getCountEmptyBag(pl) > 0) {
                           GirlkunResultSet items = GirlkunDB.executeQuery("SELECT * FROM items_web where id = ?", rs.getInt("items"));
                         if (items.first()) {
                             int item_uid = items.getInt("items");
                             int slot = items.getInt("slot");
                             Item it = ItemService.gI().createNewItem((short) item_uid , slot);
                             JSONValue jv = new JSONValue();
                             JSONArray dataArray = null;
                              dataArray = (JSONArray) jv.parse(items.getString("options"));
                              for (int i = 0 ; i < dataArray.size() ; i ++){
                                JSONArray innerArray = (JSONArray) dataArray.get(i);
                                int option = ((Long) innerArray.get(0)).intValue();
                                int param = ((Long) innerArray.get(1)).intValue(); 
                                it.itemOptions.add(new Item.ItemOption(option, param));

                              }
                        InventoryServiceNew.gI().addItemBag(pl, it);
                        InventoryServiceNew.gI().sendItemBags(pl);
                        Service.gI().sendThongBao(pl, "Bạn nhận được x " + slot + " item " + it.template.name + " từ web");
                        GirlkunDB.executeUpdate("update shops_web set status = 1 where id = ?" , id);
                          }
                            } else {
                               Service.gI().sendThongBao(pl, "vui lòng mở. rộng hành trang");
                            }
                         }
                    }
                }
               } catch (Exception e) {
               }
          }
      }
    }
}